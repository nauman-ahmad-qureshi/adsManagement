<?php 
$data = $_POST['img']; 
$data = str_replace('data:image/png;base64,', '', $data); 
$data = str_replace(' ', '+', $data); 
$data = base64_decode($data); 
$file = 'imageDir/'.  $_POST['imgName'] . '.png'; 
$success = file_put_contents($file, $data);
 ?>﻿